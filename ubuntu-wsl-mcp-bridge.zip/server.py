from __future__ import annotations

import json
import os
import platform
import re
import shutil
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Askimo Ubuntu Research Bridge")

RESEARCH_ROOT = Path.home() / "research"
PROJECTS_ROOT = RESEARCH_ROOT / "projects"
MAX_READ_BYTES = 200_000
MAX_WRITE_BYTES = 1_000_000
MAX_SEARCH_FILES = 20_000
EXCLUDED_DIRS = {".git", ".venv", "venv", "__pycache__", "node_modules", "datasets", "results"}
ALLOWED_TEXT_SUFFIXES = {
    ".py", ".pyi", ".c", ".h", ".cc", ".cpp", ".hpp", ".cu", ".cuh",
    ".rs", ".go", ".java", ".js", ".ts", ".sh", ".bash", ".md", ".txt",
    ".toml", ".yaml", ".yml", ".json", ".xml", ".html", ".css",
    ".cmake", ".make", ".cfg", ".ini",
}
BLOCKED_NAMES = {
    ".env", ".env.local", ".env.production", "credentials", "secrets",
    "id_rsa", "id_ed25519",
}
BLOCKED_SUFFIXES = {".pem", ".key", ".p12", ".pfx", ".db", ".sqlite", ".sqlite3"}
SECRET_LINE = re.compile(
    r"(?i)(\b(?:api[_-]?key|access[_-]?token|refresh[_-]?token|password|secret)\b\s*[:=]\s*)([^\s,;]+)"
)
ATOM = {"atom": "http://www.w3.org/2005/Atom"}


def _is_inside(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _project_path(relative_path: str = ".") -> Path:
    if not isinstance(relative_path, str) or "\x00" in relative_path:
        raise ValueError("Path must be a normal relative path.")
    raw = Path(relative_path)
    if raw.is_absolute():
        raise ValueError("Use a path relative to the research projects directory.")
    root = PROJECTS_ROOT.resolve(strict=False)
    candidate = (PROJECTS_ROOT / raw).resolve(strict=False)
    if not _is_inside(candidate, root):
        raise ValueError("Path escapes the research projects directory.")
    rel = candidate.relative_to(root)
    if any(part.startswith(".") or part in EXCLUDED_DIRS for part in rel.parts):
        raise ValueError("Hidden folders and generated/dependency folders are not exposed.")
    return candidate


def _text_file(path: Path) -> bool:
    name = path.name.lower()
    return (
        path.suffix.lower() in ALLOWED_TEXT_SUFFIXES
        and name not in BLOCKED_NAMES
        and path.suffix.lower() not in BLOCKED_SUFFIXES
        and not any(word in name for word in ("credential", "secret", "password", "token"))
    )


def _redact(text: str) -> str:
    return SECRET_LINE.sub(r"\1[REDACTED]", text)


def _json(data: object) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2)


@mcp.tool()
def ubuntu_status() -> str:
    """Return basic read-only information about this Ubuntu WSL environment and research directory."""
    mem_total_kb = None
    mem_available_kb = None
    try:
        for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
            if line.startswith("MemTotal:"):
                mem_total_kb = int(line.split()[1])
            elif line.startswith("MemAvailable:"):
                mem_available_kb = int(line.split()[1])
    except OSError:
        pass
    disk_path = RESEARCH_ROOT if RESEARCH_ROOT.exists() else Path.home()
    usage = shutil.disk_usage(disk_path)
    return _json({
        "system": platform.platform(),
        "python": sys.version.split()[0],
        "logical_cpus": os.cpu_count(),
        "memory_total_gib": round(mem_total_kb / 1024 / 1024, 2) if mem_total_kb else None,
        "memory_available_gib": round(mem_available_kb / 1024 / 1024, 2) if mem_available_kb else None,
        "research_root": str(RESEARCH_ROOT),
        "research_root_exists": RESEARCH_ROOT.exists(),
        "projects_root_exists": PROJECTS_ROOT.exists(),
        "disk_free_gib": round(usage.free / (1024 ** 3), 2),
    })


@mcp.tool()
def list_research_projects(path: str = ".") -> str:
    """List files and folders in the Ubuntu research/projects tree. Path is relative to that tree."""
    target = _project_path(path)
    if not target.exists():
        return _json({"path": str(target), "exists": False, "entries": []})
    if not target.is_dir():
        raise ValueError("Path must name a directory.")
    entries = []
    for item in sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
        if item.name.startswith(".") or item.name in EXCLUDED_DIRS:
            continue
        try:
            resolved = item.resolve(strict=False)
            if not _is_inside(resolved, PROJECTS_ROOT.resolve(strict=False)):
                continue
        except OSError:
            continue
        entries.append({
            "name": item.name,
            "kind": "directory" if item.is_dir() else "file",
            "bytes": item.stat().st_size if item.is_file() else None,
        })
        if len(entries) >= 300:
            break
    return _json({"path": str(target), "entries": entries, "truncated": len(entries) >= 300})


@mcp.tool()
def read_project_file(path: str) -> str:
    """Read a small text/code file under research/projects. Hidden, binary, and credential-like files are blocked."""
    target = _project_path(path)
    if not target.exists() or not target.is_file():
        raise ValueError("File does not exist.")
    if not _text_file(target):
        raise ValueError("This file type or filename is not available through the bridge.")
    size = target.stat().st_size
    if size > MAX_READ_BYTES:
        raise ValueError(f"File is {size} bytes; the read limit is {MAX_READ_BYTES} bytes.")
    content = target.read_text(encoding="utf-8", errors="replace")
    return _redact(content)


@mcp.tool()
def search_project_files(query: str, path: str = ".", max_results: int = 30) -> str:
    """Search text/code under research/projects, excluding hidden, generated, dependency, data, and results folders."""
    if not query or len(query) > 300:
        raise ValueError("Query must contain 1 to 300 characters.")
    if not isinstance(max_results, int) or max_results < 1 or max_results > 50:
        raise ValueError("max_results must be between 1 and 50.")
    start = _project_path(path)
    if not start.exists() or not start.is_dir():
        raise ValueError("Search path must be an existing project directory.")
    results = []
    scanned = 0
    needle = query.casefold()
    for current, dirs, files in os.walk(start, followlinks=False):
        current_path = Path(current)
        dirs[:] = [
            d for d in dirs
            if not d.startswith(".") and d not in EXCLUDED_DIRS
            and _is_inside((current_path / d).resolve(strict=False), PROJECTS_ROOT.resolve(strict=False))
        ]
        for name in files:
            scanned += 1
            if scanned > MAX_SEARCH_FILES:
                break
            file_path = current_path / name
            if not _text_file(file_path):
                continue
            try:
                if file_path.stat().st_size > 1_000_000:
                    continue
                lines = file_path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for line_no, line in enumerate(lines, 1):
                if needle in line.casefold():
                    results.append({
                        "file": str(file_path.relative_to(PROJECTS_ROOT.resolve(strict=False))),
                        "line": line_no,
                        "text": _redact(line[:500]),
                    })
                    if len(results) >= max_results:
                        break
            if len(results) >= max_results:
                break
        if scanned > MAX_SEARCH_FILES or len(results) >= max_results:
            break
    return _json({
        "query": query,
        "matches": results,
        "truncated": len(results) >= max_results or scanned > MAX_SEARCH_FILES,
    })


@mcp.tool()
def write_project_file(path: str, content: str, overwrite: bool = False) -> str:
    """Write a UTF-8 text/code file under research/projects. Existing files are protected unless overwrite=true."""
    target = _project_path(path)
    if not _text_file(target):
        raise ValueError("This file type or filename is not writable through the bridge.")
    if len(content.encode("utf-8")) > MAX_WRITE_BYTES:
        raise ValueError(f"Content exceeds the {MAX_WRITE_BYTES}-byte write limit.")
    if target.exists() and not overwrite:
        raise FileExistsError("File already exists. Set overwrite=true only when replacement is intended.")
    target.parent.mkdir(parents=True, exist_ok=True)
    # Re-resolve after creating parents to prevent a symlink from escaping the project tree.
    resolved = target.resolve(strict=False)
    if not _is_inside(resolved, PROJECTS_ROOT.resolve(strict=False)):
        raise ValueError("Path escapes the research projects directory.")
    resolved.write_text(content, encoding="utf-8", newline="\n")
    return _json({"written": True, "path": str(resolved), "bytes": len(content.encode("utf-8"))})


@mcp.tool()
def search_arxiv(query: str, max_results: int = 8) -> str:
    """Search the public arXiv API from Ubuntu and return paper titles, dates, abstracts, and links."""
    if not query or len(query) > 300:
        raise ValueError("Query must contain 1 to 300 characters.")
    if not isinstance(max_results, int) or max_results < 1 or max_results > 20:
        raise ValueError("max_results must be between 1 and 20.")
    arxiv_query = query if any(tag in query for tag in ("all:", "ti:", "au:", "cat:", "abs:")) else f"all:{query}"
    params = urllib.parse.urlencode({
        "search_query": arxiv_query,
        "start": 0,
        "max_results": max_results,
        "sortBy": "relevance",
        "sortOrder": "descending",
    })
    request = urllib.request.Request(
        "https://export.arxiv.org/api/query?" + params,
        headers={"User-Agent": "AskimoUbuntuResearchBridge/1.0"},
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        xml_data = response.read(2_000_000)
    root = ET.fromstring(xml_data)
    papers = []
    for entry in root.findall("atom:entry", ATOM):
        papers.append({
            "title": " ".join((entry.findtext("atom:title", default="", namespaces=ATOM)).split()),
            "published": entry.findtext("atom:published", default="", namespaces=ATOM),
            "updated": entry.findtext("atom:updated", default="", namespaces=ATOM),
            "authors": [
                author.findtext("atom:name", default="", namespaces=ATOM)
                for author in entry.findall("atom:author", ATOM)
            ],
            "abstract": " ".join((entry.findtext("atom:summary", default="", namespaces=ATOM)).split()),
            "url": entry.findtext("atom:id", default="", namespaces=ATOM),
        })
    return _json({"query": query, "count": len(papers), "papers": papers})


if __name__ == "__main__":
    mcp.run()
