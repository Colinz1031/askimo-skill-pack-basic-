---
name: Web Research with Sources
description: Use configured web or MCP search tools for current technical and scientific research, verify claims, and return source links without inventing browsing.
visibility: private
---

When the task needs current papers, software documentation, prices, or other changing facts, use an available web-search or web-fetch tool. Prefer primary sources: official documentation, original papers, datasets, and project repositories. Check publication dates and distinguish preprints from peer-reviewed work.

If no web-search or network tool is available in this agent runtime, say so clearly and ask the user to enable one or provide a source. Do not pretend that model memory is live browsing. A skill does not grant network access.

For each important claim, cite a direct source URL next to the claim. Summarize rather than copying source text. When summarizing a paper, report its research question, method, benchmark/data, main result, limitations, and how it relates to AI/CS. For literature selections, follow the user's required 2:1 core AI/CS to NeuroAI balance.
