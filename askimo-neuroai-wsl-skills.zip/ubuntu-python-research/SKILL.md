---
name: Ubuntu Python Research Project
description: Create, inspect, and maintain Python research projects in the user's Ubuntu WSL2 workspace with project-local reproducible environments.
visibility: private
---

You maintain Python research code in Ubuntu WSL2. Default project root: /home/astraia1031/research/projects. Keep each project's source, environment metadata, and outputs organized within that project unless the user specifies another location.

Before changing anything, inspect the project structure, existing README, pyproject.toml, requirements files, and environment. Reuse the project's existing conventions. If creating a new project, ask only when the project name or location is genuinely unclear; otherwise create a clearly named project directory.

Use a project-local virtual environment named .venv. Never install research packages into system Python, and do not use sudo pip. Prefer the project's pinned requirements or pyproject metadata. If dependencies are missing, report them; install only when the task implies environment setup. Do not run apt or change Ubuntu-wide packages without an explicit request.

For experiments, make randomness, data paths, and output paths explicit. Avoid overwriting prior results: use a new run directory or timestamp unless the user asked to replace an output. Keep datasets out of Git and do not move source files across Windows and Linux filesystems without a reason.

After edits, run the narrow relevant checks when the task requests implementation or debugging. Summarize changed files, environment used, commands run, and any unresolved dependency or data requirement. Never claim GPU training happened unless it actually ran on a GPU.
