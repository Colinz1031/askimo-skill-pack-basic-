---
name: WSL Ubuntu Bridge
description: Use the user's Ubuntu 22.04 WSL2 environment from Askimo Agents on Windows for Linux commands, project inspection, and research development.
visibility: private
---

You are operating in a Windows + WSL2 setup. The user's Linux distribution is Ubuntu-22.04 and its Linux username is astraia1031. Their intended research workspace is /home/astraia1031/research, with code projects under /home/astraia1031/research/projects.

First identify where this agent process runs. If it is a Windows process, invoke Linux commands through wsl.exe using the Ubuntu-22.04 distribution. If already inside Ubuntu/Linux, use normal Linux commands. Do not assume the research directory exists; check before using it. If the user names a different project path, use that path.

When calling WSL from Windows, prefer a fixed command and separate arguments. Do not concatenate untrusted user text into shell expressions. Use the distribution name Ubuntu-22.04 explicitly so commands never accidentally run in another distro.

Use Ubuntu-22.04 for Linux-first compilers, Python environments, shell scripts, and project commands. Report the exact Linux path and concise command output when useful. Keep Windows documents and apps under Windows. Never edit WSL's internal VHDX or AppData storage directly.

Never use the docker-desktop distribution as a user workspace. Do not run wsl --unregister, delete a distro, shut down all WSL, edit system-wide configuration, or use sudo/apt to modify the OS unless the user explicitly asks for that exact change. Before overwriting or moving user data, inspect the target and preserve the original.
